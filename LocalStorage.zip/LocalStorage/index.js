document.addEventListener('DOMContentLoaded', () => {
    // Load preferences when the page loads
    loadPreferences();
});

function savePreferences() {
    const theme = document.getElementById('theme').value;
    const fontSize = document.getElementById('fontSize').value;

    localStorage.setItem('theme', theme);
    localStorage.setItem('fontSize', fontSize);

    alert('Preferences saved!');
    applyPreferences();
}

function loadPreferences() {
    const theme = localStorage.getItem('theme');
    const fontSize = localStorage.getItem('fontSize');

    if (theme) {
        document.getElementById('theme').value = theme;
    }
    if (fontSize) {
        document.getElementById('fontSize').value = fontSize;
    }

    applyPreferences();
}

function applyPreferences() {
    const theme = localStorage.getItem('theme');
    const fontSize = localStorage.getItem('fontSize');

    if (theme) {
        document.body.className = theme;
    }
    if (fontSize) {
        document.body.style.fontSize = "28px";
    }
}


/* Storing data in local storage */
/* localStorage.setItem('username', 'abc');
localStorage.setItem('password', 123456); */

// let user = {
//     userName: 'abc',
//     password: '123456'
// };
// localStorage.setItem('user', JSON.stringify(user));


/* retriving the data */

// const username = localStorage.getItem('userName');
// console.log(user.userName);

/* Removing Object / local elements */
/* localStorage.removeItem('username');
localStorage.removeItem('password');
localStorage.clear(); */
// localStorage.clear();