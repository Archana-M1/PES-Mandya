import React from 'react'

function Counter() {
    return (
        <div>
            Counter
        </div>
    )
}

export default Counter
