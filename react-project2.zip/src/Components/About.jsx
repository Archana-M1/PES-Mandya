import React from 'react'
import i1 from './image1.png';
import './About.css';

function About() {
    return (
        <>
            <img src={i1} alt="" className='image' />
            <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Doloremque dolore ad sequi, minus officiis labore fuga alias sit dolor beatae nisi, iusto eveniet. Ab omnis enim sapiente minus impedit eius!</p>
            <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Doloremque dolore ad sequi, minus officiis labore fuga alias sit dolor beatae nisi, iusto eveniet. Ab omnis enim sapiente minus impedit eius!</p>
            <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Doloremque dolore ad sequi, minus officiis labore fuga alias sit dolor beatae nisi, iusto eveniet. Ab omnis enim sapiente minus impedit eius!</p>
            <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Doloremque dolore ad sequi, minus officiis labore fuga alias sit dolor beatae nisi, iusto eveniet. Ab omnis enim sapiente minus impedit eius!</p>
            <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Doloremque dolore ad sequi, minus officiis labore fuga alias sit dolor beatae nisi, iusto eveniet. Ab omnis enim sapiente minus impedit eius!</p>
            <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Doloremque dolore ad sequi, minus officiis labore fuga alias sit dolor beatae nisi, iusto eveniet. Ab omnis enim sapiente minus impedit eius!</p>
            <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Doloremque dolore ad sequi, minus officiis labore fuga alias sit dolor beatae nisi, iusto eveniet. Ab omnis enim sapiente minus impedit eius!</p>
            <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Doloremque dolore ad sequi, minus officiis labore fuga alias sit dolor beatae nisi, iusto eveniet. Ab omnis enim sapiente minus impedit eius!</p>
            <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Doloremque dolore ad sequi, minus officiis labore fuga alias sit dolor beatae nisi, iusto eveniet. Ab omnis enim sapiente minus impedit eius!</p>
            <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Doloremque dolore ad sequi, minus officiis labore fuga alias sit dolor beatae nisi, iusto eveniet. Ab omnis enim sapiente minus impedit eius!</p>
        </>
    )
}

export default About
