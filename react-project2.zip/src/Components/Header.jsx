import React from 'react'

function Header() {
    return (
        <div style={{ textAlign: "center" }}>

            <h1 style={{ letterSpacing: "2px" }}>SOFTWARE DEVELOPER</h1>
        </div>
    )
}

export default Header
