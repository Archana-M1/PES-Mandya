import React from 'react'
import About from './Components/About'

// import Footer from './Components/Footer'
import Navbar from './Components/Navbar'
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import './App.css';

import Counter from './Components/Counter';
import Home from './Components/Home';
function App() {
  return (
    <div>

      <BrowserRouter>
        <Navbar />

        <Routes>
          <Route path='/about' element={<About />} />
          <Route path='/count' element={<Counter />} />
          <Route path='/' element={<Home />} />
        </Routes>
      </BrowserRouter>

    </div>
  )
}

export default App
