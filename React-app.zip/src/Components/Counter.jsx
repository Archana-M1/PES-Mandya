import React, { useState } from 'react'

function Counter() {
    const [count, setCount] = useState(0);

    /* Increment */
    const handleIncrement = () => {
        setCount(count + 1);
    }

    /* Decrement */

    const handleDecrement = () => {
        setCount(count - 1);
    }


    return (
        <div>
            <button onClick={handleIncrement}>Click Here</button>
            <h1>{count}</h1>
            <button onClick={handleDecrement}>Click Here</button>
            {/* <h1>{count}</h1> */}
        </div>
    )
}

export default Counter
