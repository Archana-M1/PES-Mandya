import React from 'react'
import i2 from './Assets/image1.png';
import i3 from './Assets/image2.png';
import i4 from './Assets/image3.png';
import i5 from './Assets/image4.png';
import './ImageGallary.css';

function ImageGallary() {
    return (
        <div>
            <img src={i2} alt="" className='images' />
            <img src={i3} alt="" className='images' />
            <img src={i4} alt="" className='images' />
            <img src={i5} alt="" className='images' />
        </div>
    )
}

export default ImageGallary
