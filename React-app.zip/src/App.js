
import './App.css';
import ImageGallary from './Components/ImageGallary';
// import Counter from './Components/Counter';
// import Navbar from './Components/Navbar';


function App() {
  return (
    <div className="App">
      {/* <Navbar /> */}
      {/* <h1>Hello</h1> */}
      {/* <Counter /> */}
      <ImageGallary />
    </div>
  );
}

export default App;
